package com.ypyproductions.voicechanger.abtractclass.fragment;

public interface IDBFragmentConstants {
	
	public static final String KEY_NAME_FRAGMENT = "name_fragment";
	public static final String KEY_ID_FRAGMENT = "id_fragment";
	public static final String KEY_NAME_KEYWORD = "keyword";
	public static final String KEY_URL = "url";
	public static final String KEY_INDEX = "index";
	public static final String KEY_MAX_SELECTED = "max";
	public static final String KEY_PATH_IMAGE = "path_image";
}
