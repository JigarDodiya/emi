package com.ypyproductions.voicechanger;

import android.support.multidex.MultiDexApplication;

/**
 * @author:YPY Productions
 * @Skype: baopfiev_k50
 * @Mobile : +84 983 028 786
 * @Email: dotrungbao@gmail.com
 * @Website: www.ypyproductions.com
 * @Project: TemplateChangeTheme
 * Created by dotrungbao on 8/5/15.
 */

public class YPYApplication extends MultiDexApplication{

    public static final String TAG = YPYApplication.class.getSimpleName();
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
