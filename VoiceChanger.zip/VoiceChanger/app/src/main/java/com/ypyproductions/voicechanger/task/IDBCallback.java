package com.ypyproductions.voicechanger.task;

public interface IDBCallback {
	public void onAction();
}
