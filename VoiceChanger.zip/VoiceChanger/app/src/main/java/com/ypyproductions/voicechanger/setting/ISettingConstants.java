package com.ypyproductions.voicechanger.setting;

public abstract interface ISettingConstants {

	public static final String KEY_IS_ONLINE = "online";
	public static final String KEY_FIRST_TIME = "first_time";
	
	public static final String KEY_COLOR_ACCENT = "color_accent";
	public static final String KEY_COLOR_MAIN = "color_main";
	

}
