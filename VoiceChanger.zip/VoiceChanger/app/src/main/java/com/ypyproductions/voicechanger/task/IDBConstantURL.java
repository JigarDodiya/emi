package com.ypyproductions.voicechanger.task;

public abstract interface IDBConstantURL {
	public static final int DIALOG_EMPTY = 2;
	public static final int DIALOG_LOSE_CONNECTION = 1;
	public static final int DIALOG_QUIT_APPLICATION = 8;
	public static final int DIALOG_SEVER_ERROR = 19;

}
