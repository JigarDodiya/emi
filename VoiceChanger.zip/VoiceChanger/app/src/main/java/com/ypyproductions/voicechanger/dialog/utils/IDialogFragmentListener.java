package com.ypyproductions.voicechanger.dialog.utils;

public abstract interface IDialogFragmentListener {
	
	public abstract void doPositiveClick(int idDialog);
	public abstract void doNegativeClick(int idDialog);
}
