package com.ypyproductions.materialdialogs;

/**
 * @author Aidan Follestad (afollestad)
 */
public enum Theme {
    LIGHT, DARK
}