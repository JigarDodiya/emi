package com.ypyproductions.materialdialogs;

public enum GravityEnum {
    START, CENTER, END
}