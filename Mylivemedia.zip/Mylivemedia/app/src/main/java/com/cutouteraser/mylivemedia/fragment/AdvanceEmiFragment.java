package com.cutouteraser.mylivemedia.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.core.content.ContextCompat;

import com.cutouteraser.mylivemedia.R;
import com.cutouteraser.mylivemedia.utils.CustomFragment;
import com.cutouteraser.mylivemedia.utils.Global;
import com.cutouteraser.mylivemedia.utils.NumberTextWatcher;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@SuppressLint("WrongConstant")
public class AdvanceEmiFragment extends CustomFragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public int A;
    public int B;
    public double C;
    public double D;
    public double E;
    public double F;
    public double G;
    public double H;
    public double I;
    public double J;
    public double K = 0.0d;
    public double L = 0.0d;
    public double M;
//    public HistoryDatabase N;
    public EditText a;
    public EditText b;
    public EditText c;
    public EditText d;
    public EditText e;
    public RadioButton f;
    public RadioButton g;
    public Button h;
    public Button i;
    public Button j;
    public TextView k;
    public TextView l;
    public TextView m;
    private String mParam1;
    private String mParam2;
    public TextView n;
    public TextView o;
    public TextView p;
    public TextView q;
    public TextView r;
    public TextView s;
    public TextView t;
    public TextView u;
    public TextView v;
    public LinearLayout w;
    public LinearLayout x;
    public LinearLayout y;
    public LinearLayout z;

    private void Detail() {
        if (isValid()) {
//            Intent intent = new Intent(getActivity(), DetailActivity.class);
//            intent.putExtra("val_loan_amount", this.F);
//            intent.putExtra("val_interest", this.G);
//            intent.putExtra("val_period", this.A);
//            intent.putExtra("val_monthly_emi", this.E);
//            intent.putExtra("val_total_interest", this.J);
//            intent.putExtra("val_processing_fee", this.D);
//            intent.putExtra("val_total_payment", this.I);
//            intent.putExtra("gst", this.K);
//            intent.putExtra("is_reduce", this.B);
//            intent.putExtra("gst_pro_fee", this.M);
//            startActivity(intent);
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public /* synthetic */ void b(View view) {
        TextView textView;
        int i2;
        if (this.m.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
            this.m.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodUnSelect));
            textView = this.n;
            i2 = ContextCompat.getColor(getActivity(), R.color.periodSelect);
        } else {
            this.m.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodSelect));
            textView = this.n;
            i2 = ContextCompat.getColor(getActivity(), R.color.periodUnSelect);
        }
        textView.setTextColor(i2);
    }

    /* access modifiers changed from: private */
    /* renamed from: c */
    public /* synthetic */ void d(View view) {
        TextView textView;
        int i2;
        if (this.k.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
            this.k.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodUnSelect));
            textView = this.l;
            i2 = ContextCompat.getColor(getActivity(), R.color.periodSelect);
        } else {
            this.k.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodSelect));
            textView = this.l;
            i2 = ContextCompat.getColor(getActivity(), R.color.periodUnSelect);
        }
        textView.setTextColor(i2);
    }

    /* access modifiers changed from: private */
    /* renamed from: e */
    public /* synthetic */ void f(View view) {
        TextView textView;
        int i2;
        if (this.o.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
            this.o.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodUnSelect));
            textView = this.p;
            i2 = ContextCompat.getColor(getActivity(), R.color.periodSelect);
        } else {
            this.o.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodSelect));
            textView = this.p;
            i2 = ContextCompat.getColor(getActivity(), R.color.periodUnSelect);
        }
        textView.setTextColor(i2);
    }

    /* access modifiers changed from: private */
    /* renamed from: g */
    public /* synthetic */ void h(View view) {
        calculate();
    }

    private String getDateTime() {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a", Locale.getDefault()).format(new Date());
    }

    /* access modifiers changed from: private */
    /* renamed from: i */
    public /* synthetic */ void j(View view) {
        reset();
    }

    /* access modifiers changed from: private */
    /* renamed from: k */
    public /* synthetic */ void l(View view) {
        Detail();
    }

    public static AdvanceEmiFragment newInstance(String str, String str2) {
        AdvanceEmiFragment advanceEmiFragment = new AdvanceEmiFragment();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        advanceEmiFragment.setArguments(bundle);
        return advanceEmiFragment;
    }

    public void calculate() {
        closeKeyboard();
        if (isValid()) {
            this.F = Global.stringToDouble(this.a.getText().toString().replaceAll(",", "")).doubleValue();
            this.G = Global.stringToDouble(this.b.getText().toString()).doubleValue();
            this.C = this.m.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect) ? Global.stringToDouble(this.c.getText().toString()).doubleValue() * 12.0d : Global.stringToDouble(this.c.getText().toString()).doubleValue();
            this.A = (int) this.C;
            if (!this.d.getText().toString().isEmpty()) {
                String obj = this.d.getText().toString();
                if (this.o.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
                    this.D = (this.F * Global.stringToDouble(obj).doubleValue()) / 100.0d;
                } else {
                    this.D = Global.stringToDouble(obj).doubleValue();
                }
                this.L = (this.D * 18.0d) / 100.0d;
                this.M = 18.0d;
            } else {
                this.D = 0.0d;
                this.L = 0.0d;
                this.M = 0.0d;
            }
            if (this.k.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
                this.E = getEmiamount(this.F, this.C, this.G, this.D);
                this.B = 1;
            } else {
                this.E = getFixedEmiamount(this.F, this.C, this.G, this.D);
                this.B = 0;
            }
            if (this.f.isChecked()) {
                this.F -= this.E;
                this.C -= 1.0d;
                this.E = this.k.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect) ? getEmiamount(this.F, this.C, this.G, this.D) : getFixedEmiamount(this.F, this.C, this.G, this.D);
            }
            this.J = (this.E * this.C) - this.F;
            if (!this.e.getText().toString().isEmpty()) {
                double doubleValue = Global.stringToDouble(this.e.getText().toString()).doubleValue();
                this.K = doubleValue;
                this.H = (double) Math.round((this.J * doubleValue) / 100.0d);
            } else {
                this.K = 0.0d;
                this.H = 0.0d;
            }
            this.I = this.F + this.J + this.H + this.D + this.L;
            this.z.setVisibility(0);
            this.j.setVisibility(0);
            this.q.setText(Global.doubleToString(this.E));
            this.r.setText(Global.doubleToString(this.J));
            this.s.setText(Global.doubleToString(this.H));
            this.t.setText(Global.doubleToString(this.D));
            this.u.setText(Global.doubleToString(this.L));
            this.v.setText(Global.doubleToString(this.I));
//            this.N.insertRecord(new HistoryModel(this.F, this.G, this.A, this.E, this.J, this.D, this.I, getDateTime(), this.K, this.B, 18.0d));
        }
    }

    public void closeKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (getActivity().getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 2);
        }
    }

    public double getEmiamount(double d2, double d3, double d4, double d5) {
        double d6 = (d4 / 12.0d) / 100.0d;
        double pow = Math.pow(d6 + 1.0d, d3);
        return ((d2 * d6) * pow) / (pow - 1.0d);
    }

    public double getFixedEmiamount(double d2, double d3, double d4, double d5) {
        return (((d4 * d2) / 100.0d) / 12.0d) + (d2 / d3);
    }

    public boolean isValid() {
        EditText editText;
        if (Global.isZeroDouble(this.a.getText().toString())) {
            this.a.setError("Enter Loan Amount");
            editText = this.a;
        } else if (TextUtils.isEmpty(this.b.getText().toString())) {
            this.b.setError("Enter Interest");
            editText = this.b;
        } else if (!TextUtils.isEmpty(this.c.getText().toString())) {
            return true;
        } else {
            this.c.setError("Enter Tenure");
            editText = this.c;
        }
        editText.requestFocus();
        return false;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            this.mParam1 = getArguments().getString(ARG_PARAM1);
            this.mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_advance_emi, viewGroup, false);
        this.a = (EditText) inflate.findViewById(R.id.edtLoanAmount_advEmi);
        this.b = (EditText) inflate.findViewById(R.id.etInterest_advEmi);
        this.c = (EditText) inflate.findViewById(R.id.etPeriod_advEmi);
        this.d = (EditText) inflate.findViewById(R.id.etProcc_fee_advEmi);
        this.e = (EditText) inflate.findViewById(R.id.edtGst_advEmi);
        this.k = (TextView) inflate.findViewById(R.id.interest_reduce);
        this.l = (TextView) inflate.findViewById(R.id.interest_flat);
        this.m = (TextView) inflate.findViewById(R.id.periodYears_advEmi);
        this.n = (TextView) inflate.findViewById(R.id.periodMonths_advEmi);
        this.o = (TextView) inflate.findViewById(R.id.Procc_per);
        this.p = (TextView) inflate.findViewById(R.id.Procce_rs);
        RadioGroup radioGroup = (RadioGroup) inflate.findViewById(R.id.radio_grp_emiType);
        this.f = (RadioButton) inflate.findViewById(R.id.rb_advance);
        this.g = (RadioButton) inflate.findViewById(R.id.rb_arrears);
        this.h = (Button) inflate.findViewById(R.id.btnCalculate);
        this.i = (Button) inflate.findViewById(R.id.btnReset);
        this.w = (LinearLayout) inflate.findViewById(R.id.interestType);
        this.x = (LinearLayout) inflate.findViewById(R.id.periodType_advEmi);
        this.y = (LinearLayout) inflate.findViewById(R.id.PrecessingFeeType);
        this.z = (LinearLayout) inflate.findViewById(R.id.lTable_advEmi);
        this.q = (TextView) inflate.findViewById(R.id.txt_emi_advEmi);
        this.r = (TextView) inflate.findViewById(R.id.txt_interestRes_advEmi);
        this.s = (TextView) inflate.findViewById(R.id.txt_gstRes_advEmi);
        this.t = (TextView) inflate.findViewById(R.id.txt_feesRes_advEmi);
        this.u = (TextView) inflate.findViewById(R.id.txt_gstOnFees_advEmi);
        this.v = (TextView) inflate.findViewById(R.id.txt_pay_advEmi);
        this.j = (Button) inflate.findViewById(R.id.btnDetail);
//        this.N = new HistoryDatabase(getActivity());
//        this.a.addTextChangedListener(new NumberTextWatcher(getActivity(), this.a));
//        this.x.setOnClickListener(new t7(this));
//        this.w.setOnClickListener(new s7(this));
//        this.y.setOnClickListener(new u7(this));
//        this.h.setOnClickListener(new v7(this));
//        this.i.setOnClickListener(new w7(this));
//        this.j.setOnClickListener(new x7(this));
        return inflate;
    }

    public void reset() {
        this.a.setText("");
        this.b.setText("");
        this.c.setText("");
        this.d.setText("");
        this.e.setText("");
        this.a.setError((CharSequence) null);
        this.b.setError((CharSequence) null);
        this.c.setError((CharSequence) null);
        this.d.setError((CharSequence) null);
        this.e.setError((CharSequence) null);
        this.g.setChecked(true);
        this.f.setChecked(false);
        this.q.setText("");
        this.r.setText("");
        this.t.setText("");
        this.s.setText("");
        this.u.setText("");
        this.v.setText("");
        this.z.setVisibility(4);
        this.j.setVisibility(4);
    }
}
