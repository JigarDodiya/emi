package com.cutouteraser.mylivemedia.adapter;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.cutouteraser.mylivemedia.R;

public class HeaderViewHolder extends RecyclerView.ViewHolder {
    public TextView a;
    public TextView b;
    public TextView c;
    public TextView d;
    public TextView e;
    public TextView f;
    public TextView g;
    public TextView h;
    public TextView i;
    public TextView j;
    public TextView k;
    public LinearLayout l;
    public LinearLayout m;

    public HeaderViewHolder(View view) {
        super(view);
        this.a = (TextView) view.findViewById(R.id.loan_amount_result);
        this.b = (TextView) view.findViewById(R.id.interest_result);
        this.c = (TextView) view.findViewById(R.id.period_result);
        this.d = (TextView) view.findViewById(R.id.monthly_emi_result);
        this.e = (TextView) view.findViewById(R.id.total_interest_result);
        this.f = (TextView) view.findViewById(R.id.processing_fee_result);
        this.g = (TextView) view.findViewById(R.id.total_payment_result);
        this.l = (LinearLayout) view.findViewById(R.id.layout_gst_detail);
        this.h = (TextView) view.findViewById(R.id.txtGst_result);
        this.i = (TextView) view.findViewById(R.id.txt_principle_emi_heading);
        this.j = (TextView) view.findViewById(R.id.txt_interest_gst_heading);
        this.m = (LinearLayout) view.findViewById(R.id.layout_gst_onProFee_detail);
        this.k = (TextView) view.findViewById(R.id.txtGst_onProFee_result);
    }
}
