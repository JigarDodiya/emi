package com.cutouteraser.mylivemedia.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.cutouteraser.mylivemedia.R;
import com.cutouteraser.mylivemedia.modelclass.DetailModel;
import com.cutouteraser.mylivemedia.utils.Global;

import java.util.ArrayList;

public class DetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    public Bundle a;
    private final Activity activity;
    private final ArrayList<DetailModel> detailList;

    public DetailAdapter(Activity activity2, ArrayList<DetailModel> arrayList, Bundle bundle) {
        this.activity = activity2;
        this.detailList = arrayList;
        this.a = bundle;
    }

    public int getItemCount() {
        return this.detailList.size() + 1;
    }

    public int getItemViewType(int i) {
        return i == 0 ? 0 : 1;
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        String str;
        TextView textView;
        int i2;
        Activity activity2;
        LinearLayout linearLayout;
        int i3;
        Activity activity3;
        TextView textView2;
        if (viewHolder instanceof HeaderViewHolder) {
            HeaderViewHolder headerViewHolder = (HeaderViewHolder) viewHolder;
            headerViewHolder.a.setText(Global.doubleToString(this.a.getDouble("val_loan_amount")));
            headerViewHolder.b.setText(String.valueOf(this.a.getDouble("val_interest")));
            headerViewHolder.c.setText(String.valueOf(this.a.getInt("val_period")));
            headerViewHolder.d.setText(Global.doubleToString(this.a.getDouble("val_monthly_emi")));
            headerViewHolder.e.setText(Global.doubleToString(this.a.getDouble("val_total_interest")));
            headerViewHolder.f.setText(Global.doubleToString(this.a.getDouble("val_processing_fee")));
            headerViewHolder.g.setText(Global.doubleToString(this.a.getDouble("val_total_payment")));
            if (this.a.getDouble("gst") != 0.0d) {
                headerViewHolder.l.setVisibility(View.VISIBLE);
                headerViewHolder.h.setText(Global.doubleToString(this.a.getDouble("gst")));
                headerViewHolder.i.setText(this.activity.getString(R.string.emi));
                textView2 = headerViewHolder.j;
                activity3 = this.activity;
                i3 = R.string.gst;
            } else {
                headerViewHolder.l.setVisibility(View.GONE);
                headerViewHolder.h.setText("");
                headerViewHolder.i.setText(this.activity.getString(R.string.tbl_principal));
                textView2 = headerViewHolder.j;
                activity3 = this.activity;
                i3 = R.string.tbl_interest;
            }
            textView2.setText(activity3.getString(i3));
            if (this.a.getDouble("gst_pro_fee") != 0.0d) {
                headerViewHolder.m.setVisibility(View.VISIBLE);
                Log.d("nnnn", "onBindViewHolder: " + this.a.getDouble("val_processing_fee") + ",  " + this.a.getDouble("gst_pro_fee"));
                textView = headerViewHolder.k;
                str = Global.doubleToString((this.a.getDouble("val_processing_fee") * this.a.getDouble("gst_pro_fee")) / 100.0d);
            } else {
                headerViewHolder.m.setVisibility(View.GONE);
                headerViewHolder.k.setText("");
                return;
            }
        } else if (viewHolder instanceof DetailViewHolder) {
            DetailViewHolder detailViewHolder = (DetailViewHolder) viewHolder;
            if (i % 2 != 1) {
                linearLayout = detailViewHolder.e;
                activity2 = this.activity;
                i2 = R.color.lv_bg_color_two;
            } else {
                linearLayout = detailViewHolder.e;
                activity2 = this.activity;
                i2 = R.color.lv_bg_color_one;
            }
            linearLayout.setBackgroundColor(ContextCompat.getColor(activity2, i2));
            DetailModel detailModel = this.detailList.get(i - 1);
            detailViewHolder.a.setText(detailModel.getDetail_months());
            detailViewHolder.b.setText(detailModel.getDetail_principal());
            detailViewHolder.c.setText(detailModel.getDetail_interest());
            textView = detailViewHolder.d;
            str = detailModel.getDetail_balance();
        } else {
            return;
        }
        textView.setText(str);
    }

    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        if (i == 1) {
            return new DetailViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.detail_lv_row, viewGroup, false));
        }
        if (i == 0) {
            return new HeaderViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.detail_header, viewGroup, false));
        }
        return null;
    }
}
