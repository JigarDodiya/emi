package com.cutouteraser.mylivemedia.utils;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class NumberTextWatcher implements TextWatcher {
    private static final String TAG = "NumberTextWatcher";
    private DecimalFormat df;
    private DecimalFormat dfnd = ((DecimalFormat) NumberFormat.getInstance(Locale.US));
    private EditText et;
    private boolean hasFractionalPart;

    public NumberTextWatcher(Context context, EditText editText) {
        DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getInstance(Locale.US);
        this.df = decimalFormat;
        decimalFormat.setDecimalSeparatorAlwaysShown(false);
        this.df.setMaximumFractionDigits(10);
        this.et = editText;
        this.hasFractionalPart = false;
    }

    public void afterTextChanged(Editable editable) {
        EditText editText;
        String format;
        this.et.removeTextChangedListener(this);
        DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getInstance(Locale.US);
        this.df = decimalFormat;
        decimalFormat.setDecimalSeparatorAlwaysShown(false);
        this.df.setMaximumFractionDigits(10);
        this.dfnd = (DecimalFormat) NumberFormat.getInstance(Locale.US);
        try {
            int length = this.et.getText().length();
            Number parse = this.df.parse(editable.toString().replace(String.valueOf(this.df.getDecimalFormatSymbols().getGroupingSeparator()), ""));
            int selectionStart = this.et.getSelectionStart();
            if (this.hasFractionalPart) {
                editText = this.et;
                format = this.df.format(parse);
            } else {
                editText = this.et;
                format = this.dfnd.format(parse);
            }
            editText.setText(format);
            int length2 = selectionStart + (this.et.getText().length() - length);
            if (length2 <= 0 || length2 > this.et.getText().length()) {
                EditText editText2 = this.et;
                editText2.setSelection(editText2.getText().length() - 1);
            } else {
                this.et.setSelection(length2);
            }
        } catch (NumberFormatException | ParseException e) {
            e.printStackTrace();
        }
        this.et.addTextChangedListener(this);
    }

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        this.hasFractionalPart = charSequence.toString().contains(String.valueOf(this.df.getDecimalFormatSymbols().getDecimalSeparator()));
    }
}
