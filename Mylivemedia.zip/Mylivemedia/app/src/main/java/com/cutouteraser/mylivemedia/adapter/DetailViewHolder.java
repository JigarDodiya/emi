package com.cutouteraser.mylivemedia.adapter;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cutouteraser.mylivemedia.R;

public class DetailViewHolder extends RecyclerView.ViewHolder {
    public TextView a;
    public TextView b;
    public TextView c;
    public TextView d;
    public LinearLayout e;

    public DetailViewHolder(@NonNull View view) {
        super(view);
        this.e = (LinearLayout) view.findViewById(R.id.relativeLayout1);
        this.a = (TextView) view.findViewById(R.id.tvMonths_lv);
        this.b = (TextView) view.findViewById(R.id.tvPrincipal_lv);
        this.c = (TextView) view.findViewById(R.id.tvInterest_lv);
        this.d = (TextView) view.findViewById(R.id.tvBalance_lv);
    }
}
