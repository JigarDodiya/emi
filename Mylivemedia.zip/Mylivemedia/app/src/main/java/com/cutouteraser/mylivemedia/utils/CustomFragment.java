package com.cutouteraser.mylivemedia.utils;

import androidx.fragment.app.Fragment;

public abstract class CustomFragment extends Fragment {
    public abstract void reset();
}
