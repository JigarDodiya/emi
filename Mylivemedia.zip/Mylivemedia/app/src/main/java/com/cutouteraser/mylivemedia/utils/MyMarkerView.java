package com.cutouteraser.mylivemedia.utils;

import android.content.Context;
import android.widget.TextView;

import com.cutouteraser.mylivemedia.R;
import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.CandleEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;

public class MyMarkerView extends MarkerView {
    public TextView a = ((TextView) findViewById(R.id.tvContent));
    public Context b;
    public boolean c;
    public boolean d;
    public boolean e;

    public MyMarkerView(Context context, int i, boolean z, boolean z2, boolean z3) {
        super(context, i);
        this.b = context;
        this.c = z;
        this.d = z2;
        this.e = z3;
    }

    public MPPointF getOffset() {
        return new MPPointF((float) (-(getWidth() / 2)), (float) (-getHeight()));
    }

    public void refreshContent(Entry entry, Highlight highlight) {
        TextView textView;
        StringBuilder sb;
        Context context;
        int i;
        TextView textView2 = null;
        StringBuilder sb2 = null;
        String str;
        if (entry instanceof CandleEntry) {
            CandleEntry candleEntry = (CandleEntry) entry;
        } else {
            if (this.c) {
                if (highlight.getX() == 1.0f) {
                    textView2 = this.a;
                    sb2 = new StringBuilder();
                } else {
                    textView = this.a;
                    sb = new StringBuilder();
                    context = this.b;
                    i = R.string.amount_deposit;
                    sb.append(context.getString(i));
                    sb.append(" : ");
                    sb.append(Global.doubleToString((double) entry.getY()));
                    str = sb.toString();
                    textView2.setText("jigar");
                }
            } else if (this.d || this.e) {
                if (highlight.getX() == 1.0f) {
                    textView2 = this.a;
                    sb2 = new StringBuilder();
                } else {
                    textView = this.a;
                    sb = new StringBuilder();
                    context = this.b;
                    i = R.string.total_investment;
                    sb.append(context.getString(i));
                    sb.append(" : ");
                    sb.append(Global.doubleToString((double) entry.getY()));
                    str = sb.toString();
                    textView2.setText(str);
                }
            } else if (highlight.getX() == 1.0f) {
                textView2 = this.a;
                sb2 = new StringBuilder();
            } else {
                textView = this.a;
                textView2 = this.a;
                sb = new StringBuilder();
                context = this.b;
                i = R.string.loan_amount;
                sb.append(context.getString(i));
                sb.append(" : ");
                sb.append(Global.doubleToString((double) entry.getY()));
                str = sb.toString();
                textView2.setText(str);
            }
            sb2 = new StringBuilder();
            sb2.append(this.b.getString(R.string.total_interest));
            sb2.append(" : ");
            sb2.append(Global.doubleToString((double) entry.getY()));
            str = sb2.toString();
            textView2.setText(str);
        }
        super.refreshContent(entry, highlight);
    }
}
