package com.cutouteraser.mylivemedia

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

class VideoDataModel : ViewModel() {

    val Videolist = MutableLiveData<List<Folder>>()
    var job: Job? = null

    @SuppressLint("Range")
    fun getAllVideo(context: Context) {
        Log.d("Thread Outside", Thread.currentThread().name)

//        viewModelScope.launch {

            var sortValue: Int = 0

            val sortList = arrayOf(
                MediaStore.Video.Media.DATE_ADDED + " DESC",
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.TITLE + " DESC",
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.SIZE + " DESC"
            )


            val sortEditor = context.getSharedPreferences("Sorting", AppCompatActivity.MODE_PRIVATE)
            sortValue = sortEditor.getInt("sortValue", 0)
            val tempList = ArrayList<Video>()
            val tempFolderList = ArrayList<String>()
            val projection = arrayOf(
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.BUCKET_ID
            )
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortList[sortValue]
            )
            if (cursor != null)
                if (cursor.moveToNext())
                    do {
                        val titleC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.TITLE))
                                ?: "Unknown"
                        val idC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media._ID))
                                ?: "Unknown"
                        val folderC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME))
                                ?: "Internal Storage"
                        val folderIdC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_ID))
                                ?: "Unknown"
                        val sizeC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.SIZE))
                                ?: "0"
                        val pathC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DATA))
                                ?: "Unknown"
                        val durationC =
                            cursor.getString(cursor.getColumnIndex(MediaStore.Video.Media.DURATION))
                                ?.toLong() ?: 0L
                        try {
                            val file = File(pathC)
                            val artUriC = Uri.fromFile(file)
                            val video = Video(
                                title = titleC,
                                id = idC,
                                folderName = folderC,
                                duration = durationC,
                                size = sizeC,
                                path = pathC,
                                artUri = artUriC
                            )
                            if (file.exists()) tempList.add(video)
                            if (!tempFolderList.contains(folderC) && !folderC.contains("Internal Storage")) {
                                tempFolderList.add(folderC)
                                Videolist.postValue(
                                    listOf(
                                        Folder(
                                            id = folderIdC,
                                            folderName = folderC
                                        )
                                    )
                                )
                            }


                        } catch (e: Exception) {
                        }
                    } while (cursor.moveToNext())
            cursor?.close()
        }
//    }

}