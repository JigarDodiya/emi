package com.cutouteraser.mylivemedia.fragment;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.cutouteraser.mylivemedia.DetailActivity;
import com.cutouteraser.mylivemedia.R;
import com.cutouteraser.mylivemedia.utils.CustomFragment;
import com.cutouteraser.mylivemedia.utils.Global;
import com.cutouteraser.mylivemedia.utils.MyMarkerView;
import com.cutouteraser.mylivemedia.utils.MyValueFormatter;
import com.cutouteraser.mylivemedia.utils.NumberTextWatcher;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

@SuppressLint("WrongConstant")
public class NormalFragment extends CustomFragment implements View.OnClickListener {
    public RadioButton a;
    public RadioButton b;
    public Button btnCalculate;
    public Button btnDetail;
    public Button btnReset;
    public RadioButton c;
    public RadioButton d;
//    private HistoryDatabase dbHistory;
    private DecimalFormat df = new DecimalFormat("0.00");
    public PieChart e;
    public EditText etEMI;
    public EditText etFee;
    public EditText etInterest;
    public EditText etLoanAmount;
    public EditText etPeriod;
    public float f = 0.0f;
    public float g = 0.0f;
    public LinearLayout lGraph;
    public LinearLayout layoutTable;
    public TextView monthly_emi_result;
    public TextView periodMonths;
    public LinearLayout periodType;
    public TextView periodYears;
    public TextView processing_fee_result;
    public TextView total_interest_result;
    public TextView total_payment_result;

    private void Calculate() {
        getActivity().getWindow().getDecorView().clearFocus();
        if (this.a.isChecked()) {
            getLoanAmount();
        } else if (this.b.isChecked()) {
            getInterest();
        } else if (this.c.isChecked()) {
            getPeriod();
        } else if (this.d.isChecked()) {
            getEMI();
        }
    }

    private void Detail() {
        if (validate()) {
            Intent intent = new Intent(getActivity(), DetailActivity.class);
            intent.putExtra("val_loan_amount", Global.stringToDouble(this.etLoanAmount.getText().toString()));
            intent.putExtra("val_interest", Double.parseDouble(this.etInterest.getText().toString()));
            intent.putExtra("val_period", getMonth());
            intent.putExtra("val_monthly_emi", Global.stringToDouble(this.etEMI.getText().toString()));
            intent.putExtra("val_total_interest", Global.stringToDouble(this.total_interest_result.getText().toString()));
            intent.putExtra("val_processing_fee", Global.stringToDouble(this.processing_fee_result.getText().toString()));
            intent.putExtra("val_total_payment", Global.stringToDouble(this.total_payment_result.getText().toString()));
            intent.putExtra("gst", 0);
            intent.putExtra("is_reduce", 1);
            intent.putExtra("gst_pro_fee", 0);
            startActivity(intent);
        }
    }

    private void RadioEMI() {
        this.a.setChecked(false);
        this.c.setChecked(false);
        this.b.setChecked(false);
        this.etLoanAmount.setEnabled(true);
        this.etInterest.setEnabled(true);
        this.etPeriod.setEnabled(true);
        this.etEMI.setEnabled(false);
        this.etLoanAmount.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etInterest.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etPeriod.setBackgroundResource(R.drawable.rounded_edit_text_noborder);
        this.etEMI.setBackgroundResource(R.drawable.rounded_edit_text_two);
        setHint(this.etEMI);
    }

    private void RadioInterest() {
        this.a.setChecked(false);
        this.c.setChecked(false);
        this.d.setChecked(false);
        this.etLoanAmount.setEnabled(true);
        this.etInterest.setEnabled(false);
        this.etPeriod.setEnabled(true);
        this.etEMI.setEnabled(true);
        this.etLoanAmount.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etInterest.setBackgroundResource(R.drawable.rounded_edit_text_two);
        this.etPeriod.setBackgroundResource(R.drawable.rounded_edit_text_noborder);
        this.etEMI.setBackgroundResource(R.drawable.rounded_edit_text);
        setHint(this.etInterest);
    }

    private void RadioLoanAmount() {
        this.b.setChecked(false);
        this.c.setChecked(false);
        this.d.setChecked(false);
        this.etLoanAmount.setEnabled(false);
        this.etInterest.setEnabled(true);
        this.etPeriod.setEnabled(true);
        this.etEMI.setEnabled(true);
        this.etLoanAmount.setBackgroundResource(R.drawable.rounded_edit_text_two);
        this.etInterest.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etPeriod.setBackgroundResource(R.drawable.rounded_edit_text_noborder);
        this.etEMI.setBackgroundResource(R.drawable.rounded_edit_text);
        setHint(this.etLoanAmount);
    }

    private void RadioPeriod() {
        this.a.setChecked(false);
        this.b.setChecked(false);
        this.d.setChecked(false);
        this.etLoanAmount.setEnabled(true);
        this.etInterest.setEnabled(true);
        this.etPeriod.setEnabled(false);
        this.etEMI.setEnabled(true);
        this.etLoanAmount.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etInterest.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etPeriod.setBackgroundResource(R.drawable.rounded_edit_text_two);
        this.etEMI.setBackgroundResource(R.drawable.rounded_edit_text);
        setHint(this.etPeriod);
    }

    private void alertForValidation() {
//        AlertDialog.Builder createAlert = createAlert("Warning", getString(R.string.validation_msg));
//        createAlert.setNegativeButton((CharSequence) "OK", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener(this) {
//            public void onClick(DialogInterface dialogInterface, int i) {
//                dialogInterface.cancel();
//            }
//        });
//        createAlert.show();
    }

    private AlertDialog.Builder createAlert(String str, String str2) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle((CharSequence) str);
        builder.setMessage((CharSequence) str2);
        builder.setCancelable(false);
        return builder;
    }

    @SuppressLint("WrongConstant")
    private void displayResult(double d2, double d3, int i) {
        double d4 = (double) i;
        Double.isNaN(d4);
        double d5 = (d4 * d2) - d3;
        this.monthly_emi_result.setText(Global.doubleToString(d2));
        this.total_interest_result.setText(Global.doubleToString(d5));
        this.processing_fee_result.setText(Global.doubleToString(feeCalculate(d3)));
        this.total_payment_result.setText(Global.doubleToString(d3 + d5));
        this.btnDetail.setVisibility(0);
        this.layoutTable.setVisibility(0);
        insertHistoryData(i);
        this.f = (float) d3;
        this.g = (float) d5;
    }

    private double feeCalculate(double d2) {
        try {
            if (this.etFee.getText().toString().isEmpty()) {
                return 0.0d;
            }
            return (Double.parseDouble(this.etFee.getText().toString()) * d2) / 100.0d;
        } catch (Exception unused) {
            return 0.0d;
        }
    }

    private String getDateTime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a", Locale.getDefault());
        Date date = new Date();
        Log.d("fffff", "getDateTime: " + date);
        return simpleDateFormat.format(date);
    }

    private void getEMI() {
        double d2;
        if (validate()) {
            double doubleValue = Global.stringToDouble(this.etLoanAmount.getText().toString()).doubleValue();
            double parseDouble = Double.parseDouble(this.etInterest.getText().toString());
            int month = getMonth();
            if (parseDouble == 0.0d) {
                double d3 = (double) month;
                Double.isNaN(d3);
                d2 = doubleValue / d3;
            } else {
                double d4 = (parseDouble / 12.0d) / 100.0d;
                double pow = Math.pow(d4 + 1.0d, (double) month);
                d2 = ((d4 * doubleValue) * pow) / (pow - 1.0d);
            }
            double d5 = d2;
            this.etEMI.setText(Global.doubleToString(d5));
            displayResult(d5, doubleValue, month);
            setChart();
            LocalBroadcastManager.getInstance(getContext()).sendBroadcast(new Intent("Scrollview"));
        }
    }

    private void getInterest() {
        if (validate()) {
            double doubleValue = Global.stringToDouble(this.etLoanAmount.getText().toString()).doubleValue();
            double doubleValue2 = Global.stringToDouble(this.etEMI.getText().toString()).doubleValue();
            int month = getMonth();
            double d2 = (double) month;
            Double.isNaN(d2);
            if (doubleValue > doubleValue2 * d2) {
                Toast.makeText(getActivity(), getResources().getString(R.string.str_valid_data), 0).show();
                return;
            }
            float f2 = 100.0f;
            float f3 = 0.0f;
            float f4 = 0.0f;
            while (!String.valueOf(this.df.format((double) f3)).equalsIgnoreCase(String.valueOf(this.df.format((double) f2)))) {
                f4 = (f3 + f2) / 2.0f;
                double d3 = (double) (f4 / 1200.0f);
                Double.isNaN(d3);
                double d4 = doubleValue * d3;
                Double.isNaN(d3);
                double pow = Math.pow(d3 + 1.0d, d2);
                if (doubleValue2 < (d4 * pow) / (pow - 1.0d)) {
                    f2 = f4;
                } else {
                    f3 = f4;
                }
            }
            EditText editText = this.etInterest;
            editText.setText("" + Math.round(f4));
            displayResult(doubleValue2, doubleValue, month);
            setChart();
            LocalBroadcastManager.getInstance(getContext()).sendBroadcast(new Intent("Scrollview"));
        }
    }

    private void getLoanAmount() {
        double d2;
        if (validate()) {
            double parseDouble = Double.parseDouble(this.etInterest.getText().toString());
            double doubleValue = Global.stringToDouble(this.etEMI.getText().toString()).doubleValue();
            int month = getMonth();
            if (parseDouble == 0.0d) {
                double d3 = (double) month;
                Double.isNaN(d3);
                d2 = d3 * doubleValue;
            } else {
                double d4 = (parseDouble / 12.0d) / 100.0d;
                double d5 = d4 + 1.0d;
                double d6 = (double) month;
                d2 = ((Math.pow(d5, d6) - 1.0d) * doubleValue) / (d4 * Math.pow(d5, d6));
            }
            this.etLoanAmount.setText(Global.doubleToString(d2));
            displayResult(doubleValue, d2, month);
            setChart();
            LocalBroadcastManager.getInstance(getContext()).sendBroadcast(new Intent("Scrollview"));
        }
    }

    private int getMonth() {
        if (TextUtils.isEmpty(this.etPeriod.getText().toString())) {
            return 0;
        }
        return 0 + (this.periodYears.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect) ? Integer.parseInt(this.etPeriod.getText().toString()) * 12 : Integer.parseInt(this.etPeriod.getText().toString()));
    }

    private void getPeriod() {
        String str;
        EditText editText;
        if (validate()) {
            double doubleValue = Global.stringToDouble(this.etLoanAmount.getText().toString()).doubleValue();
            double parseDouble = Double.parseDouble(this.etInterest.getText().toString()) / 100.0d;
            double doubleValue2 = Global.stringToDouble(this.etEMI.getText().toString()).doubleValue();
            if (doubleValue < doubleValue2) {
                Toast.makeText(getActivity(), getResources().getString(R.string.str_valid_data), 0).show();
            } else if (parseDouble == 0.0d) {
                int round = (int) Math.round(doubleValue / doubleValue2);
                int i = round / 12;
                if (this.periodYears.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
                    this.etPeriod.setText("" + i);
                } else {
                    this.etPeriod.setText("" + round);
                }
                displayResult(doubleValue2, doubleValue, getMonth());
                setChart();
                LocalBroadcastManager.getInstance(getContext()).sendBroadcast(new Intent("Scrollview"));
            } else {
                while (parseDouble >= 1.0d) {
                    parseDouble /= 100.0d;
                }
                double d2 = (parseDouble / 12.0d) + 1.0d;
                double d3 = (d2 * doubleValue) - doubleValue2;
                if (doubleValue <= 0.0d || parseDouble <= 0.0d || doubleValue2 <= 0.0d || d3 >= doubleValue) {
                    Toast.makeText(getActivity(), getResources().getString(R.string.str_valid_data), 0).show();
                    return;
                }
                int i2 = 1;
                int i3 = 1;
                while (d3 > 0.0d) {
                    d3 = d3 < doubleValue2 ? 0.0d : (d3 * d2) - doubleValue2;
                    i3 += i2;
                    int i4 = i3 / 12;
                    if (this.periodYears.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
                        editText = this.etPeriod;
                        str = "" + i4;
                    } else {
                        editText = this.etPeriod;
                        str = "" + i3;
                    }
                    editText.setText(str);
                    i2 = 1;
                }
                displayResult(doubleValue2, doubleValue, getMonth());
                setChart();
                LocalBroadcastManager.getInstance(getContext()).sendBroadcast(new Intent("Scrollview"));
            }
        }
    }

    private void insertHistoryData(int i) {
//        HistoryModel historyModel = r1;
//        HistoryModel historyModel2 = new HistoryModel(Global.stringToDouble(this.etLoanAmount.getText().toString()).doubleValue(), Double.parseDouble(this.etInterest.getText().toString()), i, Global.stringToDouble(this.etEMI.getText().toString()).doubleValue(), Global.stringToDouble(this.total_interest_result.getText().toString()).doubleValue(), Global.stringToDouble(this.processing_fee_result.getText().toString()).doubleValue(), Global.stringToDouble(this.total_payment_result.getText().toString()).doubleValue(), getDateTime(), 0.0d, 1, 0.0d);
//        this.dbHistory.insertRecord(historyModel);
    }

    private static double log2(double d2) {
        return Math.log(d2) / Math.log(2.0d);
    }

    private boolean myValidation() {
        EditText editText;
        if (TextUtils.isEmpty(this.etLoanAmount.getText().toString())) {
            this.etLoanAmount.setError("Enter Loan Amount");
            editText = this.etLoanAmount;
        } else if (TextUtils.isEmpty(this.etInterest.getText().toString())) {
            this.etInterest.setError("Enter Interest");
            editText = this.etInterest;
        } else if (!TextUtils.isEmpty(this.etEMI.getText().toString())) {
            return true;
        } else {
            this.etEMI.setError("Enter EMI");
            editText = this.etEMI;
        }
        editText.requestFocus();
        return false;
    }

    private boolean validate() {
        EditText editText;
        if (!this.a.isChecked() && Global.isZeroDouble(this.etLoanAmount.getText().toString())) {
            this.etLoanAmount.setError("Enter Loan Amount");
            editText = this.etLoanAmount;
        } else if (!this.b.isChecked() && TextUtils.isEmpty(this.etInterest.getText().toString())) {
            this.etInterest.setError("Enter Interest");
            editText = this.etInterest;
        } else if (!this.c.isChecked() && Global.isZeroInt(this.etPeriod.getText().toString())) {
            this.etPeriod.setError("Enter Years Or Months");
            editText = this.etPeriod;
        } else if (this.d.isChecked() || !Global.isZeroDouble(this.etEMI.getText().toString())) {
            return true;
        } else {
            this.etEMI.setError("Enter EMI");
            editText = this.etEMI;
        }
        editText.requestFocus();
        return false;
    }

    @TargetApi(24)
    public Locale getCurrentLocale() {
        return Build.VERSION.SDK_INT >= 24 ? getResources().getConfiguration().getLocales().get(0) : getResources().getConfiguration().locale;
    }

    public void onClick(View view) {
        TextView textView;
        int i;
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService("input_method");
            if (getActivity().getCurrentFocus() != null) {
                inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 2);
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        int id = view.getId();
        if (id != R.id.periodType) {
            switch (id) {
                case R.id.btnCalculate:
                    Calculate();
                    return;
                case R.id.btnDetail:
                    Detail();
                    return;
                case R.id.btnReset:
                    reset();
                    return;
                default:
                    switch (id) {
                        case R.id.rbEMI:
                            RadioEMI();
                            return;
                        case R.id.rbInterest:
                            RadioInterest();
                            return;
                        case R.id.rbLoanAmount:
                            RadioLoanAmount();
                            return;
                        case R.id.rbPeriod:
                            RadioPeriod();
                            return;
                        default:
                            return;
                    }
            }
        } else {
            if (this.periodYears.getCurrentTextColor() == ContextCompat.getColor(getActivity(), R.color.periodSelect)) {
                this.periodYears.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodUnSelect));
                textView = this.periodMonths;
                i = ContextCompat.getColor(getActivity(), R.color.periodSelect);
            } else {
                this.periodYears.setTextColor(ContextCompat.getColor(getActivity(), R.color.periodSelect));
                textView = this.periodMonths;
                i = ContextCompat.getColor(getActivity(), R.color.periodUnSelect);
            }
            textView.setTextColor(i);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_normal, viewGroup, false);
//        new Preference(getActivity());
//        this.dbHistory = new HistoryDatabase(getActivity());
        this.a = (RadioButton) inflate.findViewById(R.id.rbLoanAmount);
        this.b = (RadioButton) inflate.findViewById(R.id.rbInterest);
        this.c = (RadioButton) inflate.findViewById(R.id.rbPeriod);
        this.d = (RadioButton) inflate.findViewById(R.id.rbEMI);
        this.etLoanAmount = (EditText) inflate.findViewById(R.id.etLoanAmount);
        this.etInterest = (EditText) inflate.findViewById(R.id.etInterest);
        this.etPeriod = (EditText) inflate.findViewById(R.id.etPeriod);
        this.periodYears = (TextView) inflate.findViewById(R.id.periodYears);
        this.periodMonths = (TextView) inflate.findViewById(R.id.periodMonths);
        this.etEMI = (EditText) inflate.findViewById(R.id.etEMI);
        this.etFee = (EditText) inflate.findViewById(R.id.etFee);
        this.btnCalculate = (Button) inflate.findViewById(R.id.btnCalculate);
        this.btnReset = (Button) inflate.findViewById(R.id.btnReset);
        this.btnDetail = (Button) inflate.findViewById(R.id.btnDetail);
        this.monthly_emi_result = (TextView) inflate.findViewById(R.id.monthly_emi_result);
        this.total_interest_result = (TextView) inflate.findViewById(R.id.total_interest_result);
        this.processing_fee_result = (TextView) inflate.findViewById(R.id.processing_fee_result);
        this.total_payment_result = (TextView) inflate.findViewById(R.id.total_payment_result);
        this.layoutTable = (LinearLayout) inflate.findViewById(R.id.layoutTable);
        this.periodType = (LinearLayout) inflate.findViewById(R.id.periodType);
        this.e = (PieChart) inflate.findViewById(R.id.pieChart);
        this.lGraph = (LinearLayout) inflate.findViewById(R.id.lGraph);
        this.a.setOnClickListener(this);
        this.b.setOnClickListener(this);
        this.c.setOnClickListener(this);
        this.d.setOnClickListener(this);
        this.btnCalculate.setOnClickListener(this);
        this.btnReset.setOnClickListener(this);
        this.btnDetail.setOnClickListener(this);
        this.periodType.setOnClickListener(this);
        this.etLoanAmount.addTextChangedListener(new NumberTextWatcher(getActivity(), this.etLoanAmount));
        this.etEMI.addTextChangedListener(new NumberTextWatcher(getActivity(), this.etEMI));
        this.a.setChecked(false);
        this.b.setChecked(false);
        this.c.setChecked(false);
        this.d.setChecked(true);
        this.etEMI.setEnabled(false);
        return inflate;
    }

    public void reset() {
        this.a.setChecked(false);
        this.b.setChecked(false);
        this.c.setChecked(false);
        this.d.setChecked(true);
        this.etLoanAmount.setText("");
        this.etInterest.setText("");
        this.etPeriod.setText("");
        this.etEMI.setText("");
        this.etFee.setText("");
        this.etLoanAmount.setError((CharSequence) null);
        this.etInterest.setError((CharSequence) null);
        this.etPeriod.setError((CharSequence) null);
        this.etEMI.setError((CharSequence) null);
        this.etLoanAmount.requestFocus();
        this.etLoanAmount.setEnabled(true);
        this.etInterest.setEnabled(true);
        this.etPeriod.setEnabled(true);
        this.etEMI.setEnabled(false);
        this.etLoanAmount.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etInterest.setBackgroundResource(R.drawable.rounded_edit_text);
        this.etPeriod.setBackgroundResource(R.drawable.rounded_edit_text_noborder);
        this.etEMI.setBackgroundResource(R.drawable.rounded_edit_text_two);
        this.monthly_emi_result.setText("");
        this.total_interest_result.setText("");
        this.processing_fee_result.setText("");
        this.total_payment_result.setText("");
        this.btnDetail.setVisibility(4);
        this.layoutTable.setVisibility(4);
        this.lGraph.setVisibility(8);
        this.e.clear();
    }

    public void setChart() {
        this.e.clear();
        this.lGraph.setVisibility(0);
        this.e.animateY(400);
        this.e.setUsePercentValues(true);
        this.e.getDescription().setEnabled(false);
        this.e.getLegend().setEnabled(true);
        this.e.setEntryLabelColor(-1);
        this.e.setEntryLabelTextSize(11.0f);
        this.e.setDrawEntryLabels(false);
        this.e.setNoDataTextColor(-1);
        this.e.setNoDataText((String) null);
        this.e.setUsePercentValues(true);
        Legend legend = this.e.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setTextSize(13.0f);
        MyMarkerView myMarkerView = new MyMarkerView(getContext(), R.layout.markerview_layout, false, false, false);
        myMarkerView.setChartView(this.e);
        this.e.setMarker(myMarkerView);
        ArrayList arrayList = new ArrayList();
        arrayList.add(new PieEntry(this.f, getContext().getString(R.string.loan_amount)));
        arrayList.add(new PieEntry(this.g, getContext().getString(R.string.total_interest)));
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(Integer.valueOf(ContextCompat.getColor(getContext(), R.color.orange)));
        arrayList2.add(Integer.valueOf(ContextCompat.getColor(getContext(), R.color.green_graph)));
        PieDataSet pieDataSet = new PieDataSet(arrayList, "");
        pieDataSet.setDrawIcons(false);
        pieDataSet.setColors((List<Integer>) arrayList2);
        pieDataSet.setSelectionShift(7.0f);
        pieDataSet.setSliceSpace(4.0f);
        PieData pieData = new PieData(pieDataSet);
        pieData.setValueFormatter(new MyValueFormatter(this.e));
        pieData.setValueTextSize(14.0f);
        pieData.setValueTextColor(-1);
        this.e.setDrawHoleEnabled(false);
        this.e.setData(pieData);
        this.e.notifyDataSetChanged();
        this.e.invalidate();
    }

    public void setHint(EditText editText) {
        this.etLoanAmount.setHint(getContext().getString(R.string.emi_amt_hint));
        this.etInterest.setHint(getContext().getString(R.string.emi_interest_hint));
        this.etPeriod.setHint(getContext().getString(R.string.emi_period_hint));
        this.etEMI.setHint(getContext().getString(R.string.prePay_emi_hint));
        this.etFee.setHint(getContext().getString(R.string.emi_pFee_hint));
        editText.setHint("");
    }
}
