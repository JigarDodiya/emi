package com.cutouteraser.mylivemedia.utils;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;

public class MyValueFormatter extends PercentFormatter {
    public PieChart a;

    public MyValueFormatter(PieChart pieChart) {
        this.a = pieChart;
    }

    public String getFormattedValue(float f) {
        return this.mFormat.format((double) f) + "%";
    }

    public String getPieLabel(float f, PieEntry pieEntry) {
        PieChart pieChart = this.a;
        return (pieChart == null || !pieChart.isUsePercentValuesEnabled()) ? this.mFormat.format((double) f) : getFormattedValue(f);
    }
}
