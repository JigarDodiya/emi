package com.cutouteraser.mylivemedia.utils;

import android.content.Context;
import android.graphics.Color;
import androidx.core.content.ContextCompat;

import com.cutouteraser.mylivemedia.R;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

public class PageStamper extends PdfPageEventHelper {
    public Context a;

    public PageStamper(Context context) {
        this.a = context;
    }

    public BaseColor getBaseColor(int i) {
        return new BaseColor(Color.rgb(Color.red(i), Color.green(i), Color.blue(i)));
    }

    public void onEndPage(PdfWriter pdfWriter, Document document) {
        try {
            Rectangle pageSize = document.getPageSize();
            PdfContentByte directContent = pdfWriter.getDirectContent();
            directContent.setColorFill(getBaseColor(ContextCompat.getColor(this.a, R.color.colorPrimary)));
            directContent.setFontAndSize(BaseFont.createFont(), 18.0f);
            ColumnText.showTextAligned(directContent, 2, new Phrase(String.format("Page %s", new Object[]{Integer.valueOf(pdfWriter.getCurrentPageNumber())})), pageSize.getRight(30.0f), 10.0f, 0.0f);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
