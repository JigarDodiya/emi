package com.cutouteraser.mylivemedia

data class Folder(val id: String, val folderName: String)