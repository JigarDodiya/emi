package com.cutouteraser.mylivemedia;

import static com.itextpdf.text.Font.FontFamily.TIMES_ROMAN;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cutouteraser.mylivemedia.adapter.DetailAdapter;
import com.cutouteraser.mylivemedia.modelclass.DetailModel;
import com.cutouteraser.mylivemedia.utils.Global;
import com.cutouteraser.mylivemedia.utils.PageStamper;
import com.itextpdf.text.Anchor;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class DetailActivity extends AppCompatActivity implements View.OnClickListener {
    public PdfPCell A;
    public PdfPCell B;
    public PdfPCell C;
    public PdfPCell D;
    public PdfPCell E;
    public PdfPCell F;
    public PdfPCell G;
    public PdfPCell H;
    public PdfPCell I;
    public Font J;
    public Font K;
    public Font L;
    public Font M;
    public Font N;
    public Preference P;
    public Bundle Q;
    public Calendar R1;
    public double a;
    public double b;
    public double c;
    public double d;
    public double e;
    public double f;
    public double g;
    public double h;
    public int i;
    public RecyclerView j;
    public ImageView k;
    public ImageView l;
    public ArrayList<DetailModel> m;
    public File n;
    public String o;
    public Document p;
    public PdfPTable q;
    public PdfPTable r;
    public PdfPTable s;
    public PdfPCell t;
    public PdfPCell u;
    public PdfPCell v;
    public PdfPCell w;
    public PdfPCell x;
    public PdfPCell y;
    public PdfPCell z;
    private Button sharepdf;

    public DetailActivity() {
        Font.FontFamily fontFamily = TIMES_ROMAN;
        this.M = new Font(fontFamily, 12.0f, 1);
        new Font(fontFamily, 12.0f, 1);
        this.N = new Font(fontFamily, 12.0f, 0);
    }

    private void generatePDF(Document document) throws DocumentException {
        PdfPCell pdfPCell = null;
        Phrase phrase;
        PdfPCell pdfPCell2;
        PdfPTable pdfPTable;
        int i2;
        PdfPCell pdfPCell3;
        Paragraph paragraph = new Paragraph("EMI Details", this.K);
        int i3 = 0;
        paragraph.setAlignment(0);
        document.add(paragraph);
        Paragraph paragraph2 = new Paragraph(new SimpleDateFormat("dd/MM/yyyy").format(this.R1.getTime()), this.L);
        paragraph2.setAlignment(2);
        paragraph2.setPaddingTop(30.0f);
        document.add(paragraph2);
        Paragraph paragraph3 = new Paragraph();
        paragraph3.setSpacingBefore(15.0f);
        paragraph3.setPaddingTop(10.0f);
        paragraph3.setFont(this.M);
        paragraph3.add(getString(com.cutouteraser.mylivemedia.R.string.calculated_by));
        document.add(paragraph3);
        Paragraph paragraph4 = new Paragraph();
        Anchor anchor = new Anchor(getString(com.cutouteraser.mylivemedia.R.string.app_name), new Font(TIMES_ROMAN, 12.0f, 4, getBaseColor(-16776961)));
        anchor.setReference(getString(com.cutouteraser.mylivemedia.R.string.menu_share_link) + BuildConfig.APPLICATION_ID);
        paragraph4.setPaddingTop(5.0f);
        paragraph4.add((Element) anchor);
        paragraph4.setSpacingAfter(15.0f);
        document.add(paragraph4);
        PdfPTable pdfPTable2 = new PdfPTable(new float[]{2.0f, 2.0f});
        this.q = pdfPTable2;
        pdfPTable2.setWidthPercentage(90.0f);
        this.q.setSpacingBefore(15.0f);
        this.q.setSpacingAfter(20.0f);
        this.q.setPaddingTop(40.0f);
        PdfPCell pdfPCell4 = new PdfPCell(new Phrase("Amount", this.M));
        this.t = pdfPCell4;
        pdfPCell4.setHorizontalAlignment(0);
        this.t.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.t.setPaddingBottom(7.0f);
        this.t.setPaddingLeft(7.0f);
        this.q.addCell(this.t);
        PdfPCell pdfPCell5 = new PdfPCell(new Phrase(Global.doubleToString(this.a), this.N));
        this.t = pdfPCell5;
        pdfPCell5.setHorizontalAlignment(0);
        this.t.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.t.setPaddingBottom(7.0f);
        this.t.setPaddingLeft(7.0f);
        this.q.addCell(this.t);
        PdfPCell pdfPCell6 = new PdfPCell(new Phrase("Interest %", this.M));
        this.u = pdfPCell6;
        pdfPCell6.setHorizontalAlignment(0);
        this.u.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.u.setPaddingBottom(7.0f);
        this.u.setPaddingLeft(7.0f);
        this.q.addCell(this.u);
        PdfPCell pdfPCell7 = new PdfPCell(new Phrase(String.valueOf(this.f), this.N));
        this.u = pdfPCell7;
        pdfPCell7.setHorizontalAlignment(0);
        this.u.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.u.setPaddingBottom(7.0f);
        this.u.setPaddingLeft(7.0f);
        this.q.addCell(this.u);
        PdfPCell pdfPCell8 = new PdfPCell(new Phrase("Period", this.M));
        this.v = pdfPCell8;
        pdfPCell8.setHorizontalAlignment(0);
        this.v.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.v.setPaddingBottom(7.0f);
        this.v.setPaddingLeft(7.0f);
        this.q.addCell(this.v);
        PdfPCell pdfPCell9 = new PdfPCell(new Phrase(String.valueOf(this.i), this.N));
        this.v = pdfPCell9;
        pdfPCell9.setHorizontalAlignment(0);
        this.v.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.v.setPaddingBottom(7.0f);
        this.v.setPaddingLeft(7.0f);
        this.q.addCell(this.v);
        PdfPCell pdfPCell10 = new PdfPCell(new Phrase("Monthly EMI", this.M));
        this.w = pdfPCell10;
        pdfPCell10.setHorizontalAlignment(0);
        this.w.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.w.setPaddingBottom(7.0f);
        this.w.setPaddingLeft(7.0f);
        this.q.addCell(this.w);
        PdfPCell pdfPCell11 = new PdfPCell(new Phrase(Global.doubleToString(this.b), this.N));
        this.w = pdfPCell11;
        pdfPCell11.setHorizontalAlignment(0);
        this.w.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.w.setPaddingBottom(7.0f);
        this.w.setPaddingLeft(7.0f);
        this.q.addCell(this.w);
        PdfPCell pdfPCell12 = new PdfPCell(new Phrase("Total Interest", this.M));
        this.x = pdfPCell12;
        pdfPCell12.setHorizontalAlignment(0);
        this.x.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.x.setPaddingBottom(7.0f);
        this.x.setPaddingLeft(7.0f);
        this.q.addCell(this.x);
        PdfPCell pdfPCell13 = new PdfPCell(new Phrase(Global.doubleToString(this.c), this.N));
        this.x = pdfPCell13;
        pdfPCell13.setHorizontalAlignment(0);
        this.x.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.x.setPaddingBottom(7.0f);
        this.x.setPaddingLeft(7.0f);
        this.q.addCell(this.x);
        PdfPCell pdfPCell14 = new PdfPCell(new Phrase("Processing Fee", this.M));
        this.y = pdfPCell14;
        pdfPCell14.setHorizontalAlignment(0);
        this.y.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.y.setPaddingBottom(7.0f);
        this.y.setPaddingLeft(7.0f);
        this.q.addCell(this.y);
        PdfPCell pdfPCell15 = new PdfPCell(new Phrase(Global.doubleToString(this.d), this.N));
        this.y = pdfPCell15;
        pdfPCell15.setHorizontalAlignment(0);
        this.y.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.y.setPaddingBottom(7.0f);
        this.y.setPaddingLeft(7.0f);
        this.q.addCell(this.y);
        if (this.g != 0.0d) {
            String string = getString(R.string.gst_on_interest);
            Font font = this.M;
            this.z = pdfPCell;
            pdfPCell.setHorizontalAlignment(0);
            this.z.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
            this.z.setPaddingBottom(7.0f);
            this.z.setPaddingLeft(7.0f);
            this.q.addCell(this.z);
            PdfPCell pdfPCell16 = new PdfPCell(new Phrase(Global.doubleToString(this.g), this.N));
            this.z = pdfPCell16;
            pdfPCell16.setHorizontalAlignment(0);
            this.z.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
            this.z.setPaddingBottom(7.0f);
            this.z.setPaddingLeft(7.0f);
            this.q.addCell(this.z);
            PdfPCell pdfPCell17 = new PdfPCell(new Phrase("Total Payment", this.M));
            this.A = pdfPCell17;
            pdfPCell17.setHorizontalAlignment(0);
            this.A.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
            this.A.setPaddingBottom(7.0f);
            this.A.setPaddingLeft(7.0f);
            this.q.addCell(this.A);
            PdfPCell pdfPCell18 = new PdfPCell(new Phrase(Global.doubleToString(this.e), this.N));
            this.A = pdfPCell18;
            pdfPCell18.setHorizontalAlignment(0);
            this.A.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
            this.A.setPaddingBottom(7.0f);
            this.A.setPaddingLeft(7.0f);
            pdfPTable = this.q;
            pdfPCell2 = this.A;
        } else {
            phrase = new Phrase("Total Payment", this.M);
            pdfPCell = new PdfPCell(phrase);
            this.z = pdfPCell;
            pdfPCell.setHorizontalAlignment(0);
            this.z.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
            this.z.setPaddingBottom(7.0f);
            this.z.setPaddingLeft(7.0f);
            this.q.addCell(this.z);
            PdfPCell pdfPCell19 = new PdfPCell(new Phrase(Global.doubleToString(this.e), this.N));
            this.z = pdfPCell19;
            pdfPCell19.setHorizontalAlignment(0);
            this.z.setBorderColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
            this.z.setPaddingBottom(7.0f);
            this.z.setPaddingLeft(7.0f);
            pdfPTable = this.q;
            pdfPCell2 = this.z;
        }
        pdfPTable.addCell(pdfPCell2);
        document.add(this.q);
        PdfPTable pdfPTable3 = new PdfPTable(new float[]{1.0f, 1.0f, 1.0f, 1.0f});
        this.r = pdfPTable3;
        pdfPTable3.setWidthPercentage(90.0f);
        PdfPCell pdfPCell20 = new PdfPCell(new Phrase("Month", this.J));
        this.B = pdfPCell20;
        pdfPCell20.setHorizontalAlignment(1);
        this.B.setPaddingBottom(7.0f);
        this.B.setBackgroundColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.r.addCell(this.B);
        this.C = this.g == 0.0d ? new PdfPCell(new Phrase("Principal", this.J)) : new PdfPCell(new Phrase("EMI", this.J));
        this.C.setHorizontalAlignment(1);
        this.C.setBackgroundColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.C.setPaddingBottom(7.0f);
        this.r.addCell(this.C);
        this.D = this.g == 0.0d ? new PdfPCell(new Phrase("Interest", this.J)) : new PdfPCell(new Phrase("GST", this.J));
        this.D.setHorizontalAlignment(1);
        this.D.setBackgroundColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.D.setPaddingBottom(7.0f);
        this.r.addCell(this.D);
        PdfPCell pdfPCell21 = new PdfPCell(new Phrase("Balance", this.J));
        this.E = pdfPCell21;
        pdfPCell21.setHorizontalAlignment(1);
        this.E.setBackgroundColor(getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.E.setPaddingBottom(7.0f);
        this.r.addCell(this.E);
        document.add(this.r);
        PdfPTable pdfPTable4 = new PdfPTable(new float[]{1.0f, 1.0f, 1.0f, 1.0f});
        this.s = pdfPTable4;
        pdfPTable4.setWidthPercentage(90.0f);
        if (this.m.size() > 0) {
            while (i3 < this.m.size()) {
                int i4 = i3 + 1;
                PdfPCell pdfPCell22 = new PdfPCell(new Phrase(String.valueOf(i4), this.N));
                this.F = pdfPCell22;
                pdfPCell22.setHorizontalAlignment(1);
                int i5 = i3 % 2;
                PdfPCell pdfPCell23 = this.F;
                Context applicationContext = getApplicationContext();
                pdfPCell23.setBackgroundColor(getBaseColor(i5 == 1 ? ContextCompat.getColor(applicationContext, R.color.lv_bg_color_two) : ContextCompat.getColor(applicationContext, R.color.lv_bg_color_one)));
                this.F.setPaddingBottom(7.0f);
                this.s.addCell(this.F);
                PdfPCell pdfPCell24 = new PdfPCell(new Phrase(this.m.get(i3).getDetail_principal(), this.N));
                this.G = pdfPCell24;
                pdfPCell24.setHorizontalAlignment(1);
                PdfPCell pdfPCell25 = this.G;
                Context applicationContext2 = getApplicationContext();
                pdfPCell25.setBackgroundColor(getBaseColor(i5 == 1 ? ContextCompat.getColor(applicationContext2, R.color.lv_bg_color_two) : ContextCompat.getColor(applicationContext2, R.color.lv_bg_color_one)));
                this.G.setPaddingBottom(7.0f);
                this.s.addCell(this.G);
                PdfPCell pdfPCell26 = new PdfPCell(new Phrase(this.m.get(i3).getDetail_interest(), this.N));
                this.H = pdfPCell26;
                pdfPCell26.setHorizontalAlignment(1);
                PdfPCell pdfPCell27 = this.H;
                Context applicationContext3 = getApplicationContext();
                pdfPCell27.setBackgroundColor(getBaseColor(i5 == 1 ? ContextCompat.getColor(applicationContext3, R.color.lv_bg_color_two) : ContextCompat.getColor(applicationContext3, R.color.lv_bg_color_one)));
                this.H.setPaddingBottom(7.0f);
                this.s.addCell(this.H);
                PdfPCell pdfPCell28 = new PdfPCell(new Phrase(this.m.get(i3).getDetail_balance(), this.N));
                this.I = pdfPCell28;
                pdfPCell28.setHorizontalAlignment(1);
                if (i5 == 1) {
                    pdfPCell3 = this.I;
                    i2 = ContextCompat.getColor(getApplicationContext(), R.color.lv_bg_color_two);
                } else {
                    pdfPCell3 = this.I;
                    i2 = ContextCompat.getColor(getApplicationContext(), R.color.lv_bg_color_one);
                }
                pdfPCell3.setBackgroundColor(getBaseColor(i2));
                this.I.setPaddingBottom(7.0f);
                this.s.addCell(this.I);
                i3 = i4;
            }
        }
        document.add(this.s);
    }

    /* access modifiers changed from: private */
    /* renamed from: m */
    public /* synthetic */ void n() {
//        this.P.setInteger("adCnt", 0);
        finish();
    }

    private void myOnCreate() {
        Bundle extras = getIntent().getExtras();
        this.Q = extras;
        this.a = extras.getDouble("val_loan_amount");
        this.f = this.Q.getDouble("val_interest");
        this.i = this.Q.getInt("val_period");
        this.b = this.Q.getDouble("val_monthly_emi");
        this.c = this.Q.getDouble("val_total_interest");
        this.d = this.Q.getDouble("val_processing_fee");
        this.e = this.Q.getDouble("val_total_payment");
        this.g = this.Q.getDouble("gst");
        this.h = (double) this.Q.getInt("is_reduce");
        this.Q.getInt("gst_pro_fee");
    }

    /* access modifiers changed from: private */
    /* renamed from: o */
    public /* synthetic */ void p() {
//        this.P.setInteger("adCnt", 0);
        finish();
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= 29) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
        }
    }

    private void sharePDF() {
        File cacheDir = getCacheDir();
        this.n = cacheDir;
        if (!cacheDir.exists()) {
            this.n.mkdirs();
        }
        this.o = this.n.getPath() + "/EMIDetail.pdf";
        new File(this.o);
        if (!this.n.exists()) {
            this.n.getParentFile().mkdirs();
        }
        try {
            Document document = new Document();
            this.p = document;
            PdfWriter.getInstance(document, new FileOutputStream(this.o)).setPageEvent(new PageStamper(this));
            this.p.open();
            generatePDF(this.p);
            this.p.close();
        } catch (DocumentException | IOException e2) {
            e2.printStackTrace();
        }
        Intent intent = new Intent("android.intent.action.SEND");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.putExtra("android.intent.extra.TEXT", Html.fromHtml(getString(R.string.calculated_by) + "\n" + getString(R.string.menu_share_link) + BuildConfig.APPLICATION_ID));
        intent.setType("application/pdf");
        intent.putExtra("android.intent.extra.STREAM", Build.VERSION.SDK_INT >= 21 ? FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".provider", new File(this.o)) : Uri.fromFile(new File(this.o)));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Share Via"));
    }

    public boolean checkPermission() {
        int checkSelfPermission = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
        if (Build.VERSION.SDK_INT >= 29) {
            return checkSelfPermission == 0;
        }
        return checkSelfPermission == 0 && ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
    }

    public BaseColor getBaseColor(int i2) {
        return new BaseColor(Color.rgb(Color.red(i2), Color.green(i2), Color.blue(i2)));
    }

    public void onBackPressed() {
//        InterstitialAdManager interstitialAdManager2 = this.interstitialAdManager;
//        if (interstitialAdManager2 != null) {
//            interstitialAdManager2.showAdIfAvailable(new s5(this));
//        } else {
        finish();
//        }
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.actionMenuBack) {
            finish();
        } else if (id == R.id.menuShare) {
            if (checkPermission()) {
                sharePDF();
            } else {
                requestPermission();
            }
        }
    }

    public void onCreate(Bundle bundle) {
        double d2;
        DetailModel detailModel;
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_detail);
        Preference preference = new Preference(this);
        this.P = preference;
        this.R1 = Calendar.getInstance();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.detailListView);
        sharepdf = findViewById(R.id.sharepdf);

        sharepdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sharePDF();

            }
        });

        this.j = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ImageView imageView = (ImageView) findViewById(R.id.actionMenuBack);
        this.k = imageView;
        imageView.setOnClickListener(this);
        ImageView imageView2 = (ImageView) findViewById(R.id.menuShare);
        this.l = imageView2;
        imageView2.setOnClickListener(this);
        Font.FontFamily fontFamily = TIMES_ROMAN;
        this.K = new Font(fontFamily, 20.0f, 1, getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary)));
        this.L = new Font(fontFamily, 14.0f, 0, getBaseColor(ContextCompat.getColor(getApplicationContext(), R.color.grey)));
        this.J = new Font(fontFamily, 14.0f, 0, BaseColor.WHITE);
        myOnCreate();
        this.m = new ArrayList<>();
        double d3 = this.a;
        double d4 = this.f;
        int i2 = this.i;
        double d5 = this.b;
        int i3 = (int) d3;
        long currentTimeMillis = System.currentTimeMillis();
        new DetailModel();
        double d6 = 0.0d;
        while (d6 < ((double) i2)) {
            double d7 = (d4 / 100.0d) / 12.0d;
            int i4 = i2;
            if (this.h == 1.0d) {
                double d8 = (double) i3;
                Double.isNaN(d8);
                d2 = d8 * d7;
            } else {
                d2 = d3 * d7;
            }
            double d9 = d5 - d2;
            double d10 = d3;
            double d11 = (this.g * d2) / 100.0d;
            double d12 = d4;
            double d13 = d9 + d2 + d11;
            double d14 = d5;
            double d15 = (double) i3;
            Double.isNaN(d15);
            int i5 = (int) (d15 - d9);
            i3 = i5 < 0 ? 0 : i5;
            Log.d("ADVANCE-EMI", "onCreate: " + d13 + " ,, " + d11 + ",  " + d9);
            long j2 = currentTimeMillis;
            if (this.g == 0.0d) {
                detailModel = new DetailModel(Math.round(d6 + 1.0d) + "", Global.doubleToString(d9), Global.doubleToString(d2), Global.doubleToString((double) i3));
            } else {
                detailModel = new DetailModel(Math.round(d6 + 1.0d) + "", Global.doubleToString(d13), Global.doubleToString(d11), Global.doubleToString((double) i3));
            }
            this.m.add(detailModel);
            d6 += 1.0d;
            d5 = d14;
            i2 = i4;
            d3 = d10;
            d4 = d12;
            currentTimeMillis = j2;
        }
        Log.e("C_TAG", "Native" + (System.currentTimeMillis() - currentTimeMillis));
        this.j.setAdapter(new DetailAdapter(this, this.m, this.Q));
    }
}
