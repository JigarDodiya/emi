package com.cutouteraser.mylivemedia

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.ViewModelProvider
import com.cutouteraser.mylivemedia.fragment.AdvanceEmiFragment
import com.cutouteraser.mylivemedia.fragment.NormalFragment

class MainActivity : AppCompatActivity() {
    lateinit var videoModel:VideoDataModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        videoModel = ViewModelProvider(this)[VideoDataModel::class.java]

        videoModel.Videolist.observe(this@MainActivity) {
            Log.d("viewModel", "onCreate: ${it.size}")
        }

        videoModel.getAllVideo(this)

        framload()

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fram, NormalFragment())
            .commit()

    }

    private fun framload() {



    }
}